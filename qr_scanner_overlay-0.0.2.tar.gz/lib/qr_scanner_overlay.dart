library qr_scanner_overlay;

export 'src/qr_scanner_overlay.dart';