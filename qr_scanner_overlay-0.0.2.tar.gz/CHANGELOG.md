## 0.0.2

Added a few new optional arguments
https://github.com/Govind-S-B/qr_scanner_overlay/pull/1